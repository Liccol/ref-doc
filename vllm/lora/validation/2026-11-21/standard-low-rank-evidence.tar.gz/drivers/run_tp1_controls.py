import json
import subprocess
import time
from pathlib import Path

import requests

root = Path('<VALIDATION>')
out = root / 'standard-tp-20261121'
marker = Path('<WORK_DIR>/.minimax-lora-precision.json')
for attempt in range(240):
    try:
        if requests.get('http://<HOST>:8000/v1/models', timeout=2).status_code == 200:
            break
    except requests.RequestException:
        pass
    time.sleep(2)
else:
    raise RuntimeError('Server did not become ready')
summaries = {}
try:
    for mode in ['original', 'post_reduce', 'fp32_local']:
        marker.write_text(json.dumps({'mode': mode}))
        cmd = ['python', '<ASCEND_SRC>/tests/e2e/models/minimax_m31_lora/verify.py',
               '--url', 'http://<HOST>:8000', '--tokenizer', str(root/'weights-strong/base'),
               '--reference-a', str(root/'bi-merged-a.json'), '--reference-b', str(root/'bi-merged-b.json'),
               '--trace-dir', str(out/f'tp1-{mode}-batches'), '--expected-dp', '1',
               '--output', str(out/f'tp1-{mode}.json')]
        result = subprocess.run(cmd, stdout=(out/f'tp1-{mode}-client.log').open('w'), stderr=subprocess.STDOUT)
        data = json.loads((out/f'tp1-{mode}.json').read_text())
        scores = {'tp1_merged': 0, 'tp2_merged': 0, 'same_mode_tp2_low_rank': 0}
        tp2 = json.loads((out/f'{mode}.json').read_text())
        for adapter in ['a', 'b']:
            for key, refs in [
                ('tp1_merged', json.loads((root/f'bi-merged-{adapter}.json').read_text())['serial']),
                ('tp2_merged', json.loads((root/f'bi-tp2-merged-{adapter}.json').read_text())['serial']),
                ('same_mode_tp2_low_rank', [x for x in tp2['serial'] if x['model'] == f'lora-{adapter}']),
            ]:
                for ref in refs:
                    actual = next(row for row in data['serial']
                                  if row['model'] == f'lora-{adapter}' and row['prompt_id'] == ref['prompt_id'])
                    scores[key] += all(actual[field] == ref[field] for field in
                                       ['prompt_token_ids', 'token_ids', 'finish_reason'])
        serial = {(x['model'], x['prompt_id']): x for x in data['serial']}
        mixed_passed = sum(all(x[field] == serial[x['model'], x['prompt_id']][field]
                              for field in ['prompt_token_ids', 'token_ids', 'finish_reason'])
                           for batch in data['mixed'] for x in batch)
        summaries[mode] = {'scores': scores, 'verify_exit': result.returncode, 'mixed_passed': mixed_passed,
                           'failures': data['failures'], 'batch_trace': data.get('batch_trace')}
        print(mode, scores, 'mixed_passed', mixed_passed, flush=True)
        (out/'tp1-controls-summary.json').write_text(json.dumps(summaries, indent=2))
finally:
    marker.unlink(missing_ok=True)
