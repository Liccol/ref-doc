import json
import subprocess
import time
from pathlib import Path

import requests

root = Path('<VALIDATION>')
out = root / 'standard-tp-20261121'
marker = Path('<WORK_DIR>/.minimax-lora-precision.json')
for attempt in range(240):
    try:
        if requests.get('http://<HOST>:8000/v1/models', timeout=2).status_code == 200:
            break
    except requests.RequestException:
        pass
    time.sleep(2)
else:
    raise RuntimeError('Server did not become ready')
summaries = {}
try:
    for mode in ['original', 'post_reduce', 'fp32_local']:
        marker.write_text(json.dumps({'mode': mode}))
        cmd = ['python', '<ASCEND_SRC>/tests/e2e/models/minimax_m31_lora/verify.py',
               '--url', 'http://<HOST>:8000', '--tokenizer', str(root/'weights-strong/base'),
               '--reference-a', str(root/'bi-tp2-merged-a.json'),
               '--reference-b', str(root/'bi-tp2-merged-b.json'),
               '--trace-dir', str(out/f'{mode}-batches'), '--expected-dp', '2', '--output', str(out/f'{mode}.json')]
        result = subprocess.run(cmd, stdout=(out/f'{mode}-client.log').open('w'), stderr=subprocess.STDOUT)
        data = json.loads((out/f'{mode}.json').read_text())
        scores = {'same_tp': 0, 'tp1': 0}
        for topology, prefix in [('same_tp', 'bi-tp2'), ('tp1', 'bi')]:
            for adapter in ['a', 'b']:
                refs = json.loads((root/f'{prefix}-merged-{adapter}.json').read_text())['serial']
                for ref in refs:
                    actual = next(row for row in data['serial']
                                  if row['model'] == f'lora-{adapter}' and row['prompt_id'] == ref['prompt_id'])
                    scores[topology] += all(actual[field] == ref[field] for field in
                                            ['prompt_token_ids', 'token_ids', 'finish_reason'])
        summaries[mode] = {'scores': scores, 'verify_exit': result.returncode,
                           'failures': data['failures'], 'batch_trace': data.get('batch_trace')}
        print(mode, scores, 'failures', len(data['failures']), flush=True)
        (out/'controls-summary.json').write_text(json.dumps(summaries, indent=2))
finally:
    marker.unlink(missing_ok=True)
